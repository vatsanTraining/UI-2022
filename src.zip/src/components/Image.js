import React from 'react'

export const Image = ({imgRef,imgText}) => {
  return (
    <img src={imgRef} alt={imgText} className="img-fluid image"></img>
    )
}

