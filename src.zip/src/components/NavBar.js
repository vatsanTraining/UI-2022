import React from 'react'

export const NavBar = ({links}) => {

   const createLink =(element,idx) =>{
    return <a href={element.link} key={idx} className='nav-item'>{element.linkText}</a>
   } 
  return (
    <nav className='navbar'>
        {
         links.map(createLink)
        }
    </nav>
  )
}
