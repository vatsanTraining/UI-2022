import React from 'react'

export const ShowDrivers = ({list}) => {
    const transformToRow = (element,idx) =>{
        return <tr key={idx}>
             <td>{element.id}</td>
             <td>{element.driverName.toUpperCase()}</td>
             <td>{element.rating}</td>
             <td><button>Delete</button></td>
            <td><button>Edit</button></td>
         </tr>
     }
  
    return (
    <div>
        <h1>Driver Partner List</h1>
        <table className='table table-bordered table-striped'>
         <thead>
            <tr>
                <th>Driver Id</th>
                <th>Driver Name</th>
                <th>Rating</th>
            </tr>
         </thead>
         <tbody>
        {
            list.map(transformToRow)
        }
        </tbody>
        </table>
    </div>
  )

}
