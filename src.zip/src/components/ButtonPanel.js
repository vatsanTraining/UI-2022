import React from 'react'

export const ButtonPanel = ({love,like}) => {
  return (
    <div>
        <button className='btn btn-info' onClick={like}>Like</button>
         <button className='btn btn-warning' onClick={love}>Love</button>


    </div>
  )
}
