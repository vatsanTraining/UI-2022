import React from 'react'

export const AddDriver = ({change,submit,driver}) => {

    const {id,driverName,rating}= driver;
  return (
    <div>
        
        <form onSubmit={submit}>

<div className='form-group'>
    <label htmlFor="">Driver Id</label>
    <input type="text" className='form-control' name="id" 
    onChange={change} value={id || ''}/>
</div>

<div className='form-group'>
    <label htmlFor="">Driver Name</label>
    <input type="text" className='form-control' name="driverName" 
    onChange={change} value={driverName || ''}/>
</div>

<div className='form-group'>
    <label htmlFor="">Rating</label>
    <input className='form-control'  type="text" name="rating" 
    onChange={change} value={rating || ''}/>
</div>

<div>
    <input type="submit" className='btn btn-info' value='Submit'/>
    </div>
</form>

Footer
    </div>
  )
}
