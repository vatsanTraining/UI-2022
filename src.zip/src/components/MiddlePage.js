import React,{useState} from 'react'
import { ButtonPanel } from './ButtonPanel';
export const MiddlePage = () => {

    const [likeCount,setLikeCount] =useState(1);
    const [loveCount,setLoveCount] =useState(1);

    const handleLove = () =>{
        setLoveCount(loveCount => loveCount+1)

    }
    const handleLike = () =>{
        setLikeCount(likeCount => likeCount+1)

    }

  return (
    
   
    <div>
        <p>Like:{likeCount}</p>
        <p>Love:{loveCount}</p>
        <ButtonPanel love={handleLove} like={handleLike}></ButtonPanel>

    </div>
  )
}
