import React from 'react'
import { Image } from './Image'
import logo from '../images/logo.jpeg'
import { NavBar } from './NavBar'
export const Header = ({heading,location}) => {
  const links = [
    {"link":"home","linkText":"Home"},
   {"link":"trips","linkText":"Trips"},
   {"link":"drivers","linkText":"Drivers"}
 ]
  return (
    <div>
        <h1>{heading}</h1>
        <h4>{location}</h4>
        <NavBar links={links}></NavBar>
<Image imgRef={logo} imgText={'corporate logo'}></Image>
    </div>
  )
}
