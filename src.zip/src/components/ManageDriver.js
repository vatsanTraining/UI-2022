import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { ShowDrivers } from './ShowDrivers';
import { AddDriver } from './AddDriver';
export const ManageDriver = () => {

    const initial ={id:'',driverName:'',rating:''};
    const [driver,setDriver] =useState(initial)
       
    const handleChange = (event) =>{
        let name =event.target.name;
        let value =event.target.value;
       setDriver(obj => ({...obj, [name]: value}))
       
       console.log(driver)

    }

    const handleSubmit = (event)=>{
        event.preventDefault();
        axios.post("http://localhost:4000/drivers",driver)
                 .then(response =>{ 
                  setDriverList(prevState => [...prevState,driver]);
                   setDriver(initial)       
      })

    }
    const [driverList,setDriverList] =useState([]);

    let  getData = async () =>{

        let response =  await  axios.get("http://localhost:4000/drivers");
  
        setDriverList(response.data);
  
      }
      useEffect(()=>{
        getData();
      },[]);

  return (
    <div>
        <AddDriver driver={driver} change={handleChange} submit={handleSubmit}></AddDriver>
 <ShowDrivers list={driverList}></ShowDrivers>
    </div>
  )
}
