import logo from './logo.svg';
import './App.css';
import {Header} from './components/Header'
import Content from './components/Content';
import { MiddlePage } from './components/MiddlePage';
import { ManageDriver } from './components/ManageDriver';

function App() {
  return (
    <div className="App">
      <Header heading={'Radio Taxi Service'} location={'Chennai'}></Header>
      <ManageDriver></ManageDriver>
    </div>
  );
}

export default App;
