const initialState = {
    firstName:'virat',
    lastName:'kohli'
}

const  NameReducer  =  (state = initialState, { type, payload }) => {
  switch (type) {

  case 'SET_FIRST_NAME':
    return { ...state,
        firstName: payload }
    case 'SET_LAST_NAME':
        return{
            ...state ,lastName:payload
        }
  default:
    return state
  }
}

export default NameReducer;