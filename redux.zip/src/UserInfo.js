import React from 'react'
import { useSelector, useDispatch } from 'react-redux';

export const UserInfo = () => {

    const { firstName } = useSelector((state)=> state.names);

     const { lastName } = useSelector((state)=> state.names);

     const nameDispatch = useDispatch();

    const handleFirstNameClick = () =>{

        nameDispatch({type:'SET_FIRST_NAME',payload:'jasprit'})
    }
    const handleLastNameClick = () =>{
        nameDispatch({type:'SET_LAST_NAME',payload:'bumrah'})
    }

  return (

    <div>
        <h2>User Info</h2>
           <p>{firstName}</p>
        <p>{lastName}</p>

        <button onClick={handleFirstNameClick}>First Name</button>
        <button onClick={handleLastNameClick}>Last Name</button>


    </div>
  )
}
