import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

const initialState = {
  drivers: [],
  loading: false,
}

export const getDrivers = createAsyncThunk(
  'driver/getDrivers',
  async (thunkAPI) => {
    const res = await fetch('http://localhost:4000/drivers').then(
    (data) => data.json()
  )
  return res
})


export const driverSlice = createSlice({
  name: 'drivers',
  initialState,
  reducers: {},
  extraReducers: {
    [getDrivers.pending]: (state) => {
      state.loading = true
    },
    [getDrivers.fulfilled]: (state, { payload }) => {
      state.loading = false
      state.drivers = payload
    },
    [getDrivers.rejected]: (state) => {
      state.loading = false
    },
  },
})

export const driverReducer = driverSlice.reducer