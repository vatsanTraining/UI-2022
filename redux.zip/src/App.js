import React from 'react';
import './App.css';
import Application from './Application';
import { ManageDriverRatings } from './ManageDriverRatings';
import { ManageDrivers } from './ManageDrivers';
import SecondApplication from './SecondApplication';
import { UserInfo } from './UserInfo';

function App() {
  return (
    <div className="container">
      <h1>Redux</h1>
      <div className='row'>
        <div className='col-md-6'>
        <Application></Application>

        </div>
        <div className='col-md-6'>
        <SecondApplication></SecondApplication>
        </div>

      </div>
      <div className='row'> 
      <UserInfo></UserInfo>
   <ManageDrivers></ManageDrivers>
   <ManageDriverRatings></ManageDriverRatings>
      </div>
    </div>
  );
}

export default App;
