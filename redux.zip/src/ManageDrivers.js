import React from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getDrivers } from './DriverReducer'

export const ManageDrivers = () => {

    const dispatch = useDispatch()
     const { drivers, loading } = useSelector((state) => state.driver)

     console.log(loading)
     console.log(drivers)
    useEffect(() => {
        dispatch(getDrivers())

      }, [])

       if (loading) return <p>Loading...</p>

  return (
    <div>
      <h2>Driver List</h2>
      {drivers.map((element) => (
        <p key={element.id}>{element.driverName}</p> 
       ))
      }

    </div>
  )
}
