import React from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getDrivers } from './DriverReducer'

export const ManageDriverRatings = () => {
    const dispatch = useDispatch()
    const { drivers, loading } = useSelector((state) => state.driver)

   useEffect(() => {
       dispatch(getDrivers())

     }, [])

     if (loading) return <p>Loading...</p>

    return (
    <div>
        

      <h2>Driver Rating List</h2>
      {drivers.map((element) => (
        <p key={element.id}>{element.driverName} {element.rating}</p> 
       ))
      }

    </div>
  )

    } 

